#!/usr/bin/env python3

from brain_games.games.game_even import start_even_game


def main():
    start_even_game()


if __name__ == "__main__":
    main()
