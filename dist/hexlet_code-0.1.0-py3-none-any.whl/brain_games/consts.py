EVEN_GAME_DESCRIPTION = 'Answer "yes" if the number is even, otherwise answer "no".'
CALC_GAME_DESCRIPTION = 'What is the result of the expression?'
GCD_GAME_DESCRIPTION = 'Find the greatest common divisor of given numbers.'
PROGRESSION_GAME_DESCRIPTION = 'What number is missing in the progression?'
PRIME_GAME_DESCRIPTION = 'Answer "yes" if given number is prime, otherwise answer "no".'

MATH_SIGNS = ('+', '-', '*')