### Hexlet tests and linter status:
[![Actions Status](https://github.com/tarasich100/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/tarasich100/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/05b05ef2c307951ffbd2/maintainability)](https://codeclimate.com/github/tarasich100/python-project-49/maintainability)
