### Hexlet tests and linter status:
[![Actions Status](https://github.com/tarasich100/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/tarasich100/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/05b05ef2c307951ffbd2/maintainability)](https://codeclimate.com/github/tarasich100/python-project-49/maintainability)
[![asciicast](https://asciinema.org/a/4sgoXU9GI8C2oPAbifAYuoZoE.svg)](https://asciinema.org/a/4sgoXU9GI8C2oPAbifAYuoZoE)
[![asciicast](https://asciinema.org/a/4grmK0Q5QWEltoH1gJpgmUYXk.svg)](https://asciinema.org/a/4grmK0Q5QWEltoH1gJpgmUYXk)
