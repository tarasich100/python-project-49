#!/usr/bin/env python3

from brain_games.games.game_progression import start_progression_game


def main():
    start_progression_game()


if __name__ == "__main__":
    main()
