#!/usr/bin/env python3

from brain_games.games.game_gcd import start_gcd_game


def main():
    start_gcd_game()


if __name__ == "__main__":
    main()
