from brain_games.games.brain_calc import start_calc_game


def main():
    start_calc_game()

if __name__ == "__main__":
    main()
